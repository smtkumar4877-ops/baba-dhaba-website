# Baba Dhaba — Restaurant website starter

A mobile-first React + Tailwind frontend and Express + SQLite API starter for Baba Dhaba, Koderma.

## Configured restaurant details
- Map pin: `24.4360136, 85.5194114` (resolved from the Google Maps link supplied)
- Delivery radius: 2 km
- Delivery fee: ₹20
- Minimum order: ₹149
- Delivery estimate shown: 30–40 minutes
- Phone, opening hours, email, social accounts and exact street address: placeholders until confirmed.

## Run locally
1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set a strong `JWT_SECRET` and a new `ADMIN_PASSWORD`.
5. Run `npm run dev`.
6. Open `http://localhost:5173`.

The Vite frontend currently calls `/api/...`; for local development, add this proxy to `vite.config.js` if desired:
```js
server: { port: 5173, proxy: { '/api': 'http://localhost:4000' } }
```

## Important before launch
- This is a starter project, not a deployed live ordering service. Deploy frontend and API, configure HTTPS, backups, monitoring and production CORS.
- Admin authentication is a minimal starter. Before public launch, replace it with a robust login flow, rate limiting, secure cookie/session handling, CSRF protections, password hashing at setup time, audit logging and account recovery.
- UPI is currently a selected payment preference only; no payment is collected. Integrate a compliant payment provider and verify payment server-side before marking paid.
- The WhatsApp action uses a generic share link because the restaurant number has not been supplied. Add the verified WhatsApp number before launch.
- Order/reservation confirmation is not a real-time SMS or WhatsApp notification. Add notification integration after owner consent and credentials.
- The map uses OpenStreetMap tiles via Leaflet. Respect the tile provider's usage policy; for higher traffic use a suitable tile provider.
- The contact form is demo-only and needs a backend endpoint, spam protection and privacy notice.
- Admin API endpoints are included for orders, reservations, menu CRUD and settings; a dedicated admin dashboard UI still needs to be built.
- Restaurant owner should verify the actual pin, delivery boundary, menu, prices, food images, hours, legal notices, food licence details and contact information.
- Delivery radius check is straight-line Haversine distance, not road distance. Customer must drop a pin on the map; address autocomplete/geocoding is not wired yet.
