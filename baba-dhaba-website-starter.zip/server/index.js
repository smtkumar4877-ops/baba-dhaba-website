require('dotenv').config()
const express = require('express')
const cors = require('cors')
const Database = require('better-sqlite3')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const path = require('path')
const app = express()
const db = new Database(path.join(__dirname, 'baba-dhaba.sqlite'))
const PORT = process.env.PORT || 4000
app.use(cors({origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173'}))
app.use(express.json({limit:'1mb'}))
db.exec(`
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT, phone TEXT, address TEXT, payload TEXT, status TEXT DEFAULT 'Received', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reservations(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, email TEXT, date TEXT, time TEXT, guests TEXT, requests TEXT, status TEXT DEFAULT 'Pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS menu_items(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, price INTEGER, image TEXT, category TEXT, tags TEXT, available INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
`)
const defaults={delivery_radius_km:'2',delivery_fee:'20',minimum_order:'149',opening_hours:'Please update opening hours'}
for(const [k,v] of Object.entries(defaults)) db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)').run(k,v)
const seed=db.prepare('SELECT COUNT(*) n FROM menu_items').get().n
if(!seed){const ins=db.prepare('INSERT INTO menu_items(name,description,price,image,category,tags) VALUES(?,?,?,?,?,?)');[
 ['Paneer Tikka','Tandoor-grilled paneer',189,'','Starters','Veg,Bestseller'],
 ['Dal Makhani','Slow-cooked black lentils',179,'','Main Course Veg','Veg'],
 ['Chicken Curry','Dhaba-style chicken curry',249,'','Main Course Non-Veg','Non-Veg,Spicy'],
 ['Veg Biryani','Fragrant basmati rice',169,'','Rice & Biryani','Veg']
].forEach(x=>ins.run(...x))}
app.get('/api/health',(req,res)=>res.json({ok:true,restaurant:'Baba Dhaba'}))
app.get('/api/menu',(req,res)=>res.json(db.prepare('SELECT * FROM menu_items WHERE available=1 ORDER BY category,name').all()))
app.post('/api/orders',(req,res)=>{
 const p=req.body||{}, settings=Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]))
 const min=Number(settings.minimum_order||149), fee=Number(settings.delivery_fee||20), radius=Number(settings.delivery_radius_km||2)
 if(!p.name||!p.phone||!/^[6-9]\d{9}$/.test(p.phone)) return res.status(400).json({error:'Valid name and 10-digit Indian phone required'})
 if(!Array.isArray(p.items)||!p.items.length) return res.status(400).json({error:'Cart is empty'})
 if(Number(p.subtotal)<min) return res.status(400).json({error:`Minimum order is ₹${min}`})
 if(p.fulfilment==='Delivery'){
  if(!p.customerLocation||!Number.isFinite(Number(p.distanceKm))||Number(p.distanceKm)>radius) return res.status(400).json({error:`Sorry, we only deliver within ${radius} km. You can choose Pickup instead.`})
 }
 const delivery=p.fulfilment==='Delivery'?fee:0
 const id=db.prepare('INSERT INTO orders(customer_name,phone,address,payload,status) VALUES(?,?,?,?,?)').run(p.name,p.phone,p.address||'',JSON.stringify({...p,deliveryFee:delivery,total:Number(p.subtotal)+delivery}),'Received').lastInsertRowid
 res.status(201).json({orderId:id,status:'Received',estimatedMinutes:'30-40'})
})
app.post('/api/reservations',(req,res)=>{const p=req.body||{};if(!p.name||!p.phone||!p.date||!p.time)return res.status(400).json({error:'Name, phone, date and time are required'});const r=db.prepare('INSERT INTO reservations(name,phone,email,date,time,guests,requests) VALUES(?,?,?,?,?,?,?)').run(p.name,p.phone,p.email||'',p.date,p.time,p.guests||'2',p.requests||'');res.status(201).json({reservationId:r.lastInsertRowid,status:'Pending'})})
function auth(req,res,next){try{const token=(req.headers.authorization||'').replace(/^Bearer /,'');req.admin=jwt.verify(token,process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:'Admin login required'})}}
app.post('/api/admin/login',async(req,res)=>{const {username,password}=req.body||{};const expected=process.env.ADMIN_PASSWORD||'';if(!expected||username!== (process.env.ADMIN_USERNAME||'admin') || !(await bcrypt.compare(password||'',await bcrypt.hash(expected,10))))return res.status(401).json({error:'Invalid credentials'});res.json({token:jwt.sign({role:'admin'},process.env.JWT_SECRET||'development-only-change-me',{expiresIn:'8h'})})})
app.get('/api/admin/orders',auth,(req,res)=>res.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all().map(x=>({...x,payload:JSON.parse(x.payload)}))))
app.patch('/api/admin/orders/:id',auth,(req,res)=>{const allowed=['Received','Preparing','Out for Delivery','Delivered'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid status'});db.prepare('UPDATE orders SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true})})
app.get('/api/admin/reservations',auth,(req,res)=>res.json(db.prepare('SELECT * FROM reservations ORDER BY id DESC').all()))
app.get('/api/admin/menu',auth,(req,res)=>res.json(db.prepare('SELECT * FROM menu_items ORDER BY id DESC').all()))
app.post('/api/admin/menu',auth,(req,res)=>{const p=req.body||{};if(!p.name||!p.category||!Number.isFinite(Number(p.price)))return res.status(400).json({error:'Name, category and price required'});const r=db.prepare('INSERT INTO menu_items(name,description,price,image,category,tags,available) VALUES(?,?,?,?,?,?,?)').run(p.name,p.description||'',Number(p.price),p.image||'',p.category,p.tags||'',p.available===false?0:1);res.status(201).json({id:r.lastInsertRowid})})
app.put('/api/admin/menu/:id',auth,(req,res)=>{const p=req.body||{};db.prepare('UPDATE menu_items SET name=?,description=?,price=?,image=?,category=?,tags=?,available=? WHERE id=?').run(p.name,p.description||'',Number(p.price),p.image||'',p.category,p.tags||'',p.available===false?0:1,req.params.id);res.json({ok:true})})
app.delete('/api/admin/menu/:id',auth,(req,res)=>{db.prepare('DELETE FROM menu_items WHERE id=?').run(req.params.id);res.json({ok:true})})
app.get('/api/admin/settings',auth,(req,res)=>res.json(Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(x=>[x.key,x.value]))))
app.put('/api/admin/settings',auth,(req,res)=>{for(const [k,v] of Object.entries(req.body||{}))if(['delivery_radius_km','delivery_fee','minimum_order','opening_hours'].includes(k))db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k,String(v));res.json({ok:true})})
app.listen(PORT,()=>console.log(`Baba Dhaba API running on http://localhost:${PORT}`))
